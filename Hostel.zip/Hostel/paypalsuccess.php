<?php
include_once 'db_connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment SuccessFull</title>
    <link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
    <link rel="manifest" href="favicon.ico/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .br {
            border-radius: 30px;
        }

        .bs {
            box-shadow: 5px 5px 2px #809092;
        }

        .b-card {
            border: none !important;
        }
    </style>
</head>

<body>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="card  mt-3 bs br">
                <div class="card-body">
                    <?php
                    $paymentid = $_GET['payid'];
                    $results = mysqli_query($db_conn, "SELECT * FROM payments where id='$paymentid' ");
                    $row = mysqli_fetch_array($results);
                    ?>
                    <img class=" card-img-top" src="img2/success.gif" alt="success" style="height: min-content;">
                    <h4 class="text-black-50 text-center">Your Payment Has been Successful !</h4><br>
                    <div class="font-weight-bold text-capitalize">
                        <p>Reference Number:
                            <span class="font-weight-lighter"><?php echo $row['invoice_id']; ?></span>
                        </p><br>
                        <p>Transaction ID:
                            <span class="font-weight-lighter"><?php echo $row['transaction_id']; ?></span>
                        </p><br>
                        <p>Paid Amount: $
                            <span class="font-weight-lighter"><?php echo $row['payment_amount']; ?></span>
                        </p><br>
                        <p>Payment Status:
                            <span class="font-weight-lighter"><?php echo $row['payment_status']; ?></span>
                        </p>

                    </div>
                    <div class="text-center mt-1">
                        <a href="dashboard.php" class="btn btn-outline-success">Dashboard</a>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div>
</body>

</html>