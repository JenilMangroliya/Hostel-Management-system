<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PayPal\Api\Amount;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Api\ItemList;

require 'config2.php';
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();
//code for registration
if (isset($_POST['submit'])) {
	// print_r($_POST);
	// die;
	$roomno = $_POST['room'];


	$seater = $_POST['seater'];
	$feespm = $_POST['fpm'];
	$foodstatus = $_POST['foodstatus'];
	$stayfrom = $_POST['stayf'];
	$duration = $_POST['duration'];
	$course = $_POST['course'];
	$regno = $_POST['regno'];
	$fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$lname = $_POST['lname'];
	$gender = $_POST['gender'];
	$contactno = $_POST['contact'];
	$emailid = $_POST['email'];
	$emcntno = $_POST['econtact'];
	$gurname = $_POST['gname'];
	$gurrelation = $_POST['grelation'];
	$gurcntno = $_POST['gcontact'];
	$caddress = $_POST['address'];
	$ccity = $_POST['city'];
	$cstate = $_POST['state'];
	$cpincode = $_POST['pincode'];
	$paddress = $_POST['paddress'];
	$pcity = $_POST['pcity'];
	$pstate = $_POST['pstate'];
	$ppincode = $_POST['ppincode'];



	$query = "insert into  registration(roomno,seater,feespm,foodstatus,stayfrom,duration,course,regno,firstName,middleName,lastName,gender,contactno,emailid,egycontactno,guardianName,guardianRelation,guardianContactno,corresAddress,corresCIty,corresState,corresPincode,pmntAddress,pmntCity,pmnatetState,pmntPincode) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	$stmt = $mysqli->prepare($query);
	$rc = $stmt->bind_param('iiiisisissssisississsisssi', $roomno, $seater, $feespm, $foodstatus, $stayfrom, $duration, $course, $regno, $fname, $mname, $lname, $gender, $contactno, $emailid, $emcntno, $gurname, $gurrelation, $gurcntno, $caddress, $ccity, $cstate, $cpincode, $paddress, $pcity, $pstate, $ppincode);
	$stmt->execute();
	$last_id = $mysqli->insert_id;
	$_SESSION['PayPal_order_id'] = $last_id;

	$result = $mysqli->query("select fees,id from rooms where room_no={$roomno} limit 1");
	$res = $result->fetch_array();

	$fee = $res['fees'] * $duration;
	$room_id = $res['id'];
	if ($foodstatus == 1) {
		$f_fee = 20 * $duration;
	} else {
		$f_fee = 0;
	}
	$total_fee = $fee + $f_fee;

	if (empty($_POST['duration'])) {
		throw new Exception('This script should not be called directly, expected post data');
	}

	$payer = new Payer();
	$payer->setPaymentMethod('paypal');

	// Set some example data for the payment.
	$currency = 'USD';
	$item_qty = 1;
	$amountPayable = $total_fee;
	$product_name = "room no: " . $roomno;
	$item_code = 1;
	$description = 'Paypal transaction';
	$invoiceNumber = uniqid();
	$my_items = array(
		array('name' => $product_name, 'quantity' => $item_qty, 'price' => $amountPayable, 'sku' => $item_code, 'currency' => $currency)
	);

	$amount = new Amount();
	$amount->setCurrency($currency)
		->setTotal($amountPayable);

	$items = new ItemList();
	$items->setItems($my_items);

	$transaction = new Transaction();
	$transaction->setAmount($amount)
		->setDescription($description)
		->setInvoiceNumber($invoiceNumber)
		->setItemList($items);

	$redirectUrls = new RedirectUrls();
	$redirectUrls->setReturnUrl($paypalConfig['return_url'])
		->setCancelUrl($paypalConfig['cancel_url']);

	$payment = new Payment();
	$payment->setIntent('sale')
		->setPayer($payer)
		->setTransactions([$transaction])
		->setRedirectUrls($redirectUrls);

	try {
		$payment->create($apiContext);
	} catch (Exception $e) {
		throw new Exception('Unable to create link for payment');
	}

	header('location:' . $payment->getApprovalLink());

	echo "<script>alert('Student Succssfully register');</script>";
}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Student Hostel Registration</title>
	<link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
	<link rel="manifest" href="favicon.ico/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">

	<link rel="stylesheet" href="css2/font-awesome.min.css">
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css2/bootstrap-social.css">
	<link rel="stylesheet" href="css2/bootstrap-select.css">
	<link rel="stylesheet" href="css2/fileinput.min.css">
	<link rel="stylesheet" href="css2/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css2/style.css">



	<script type="text/javascript" src="js2/jquery-1.11.3-jquery.min.js"></script>
	<script type="text/javascript" src="js2/validation.min.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	<script>
		function getSeater(val) {
			$.ajax({
				type: "POST",
				url: "get_seater.php",
				data: 'roomid=' + val,
				success: function(data) {
					//alert(data);
					$('#seater').val(data);
					// $('#fpm').val(data);

				}
			});

			$.ajax({
				type: "POST",
				url: "get_seater.php",
				data: 'rid=' + val,
				success: function(data) {
					//alert(data);
					$('#fpm').val(data);
				}
			});
		}

		function getTotal() {
			const fpm = $('#fpm').val();
			const fpm2 = parseInt(fpm);

			const food = $('input[name="foodstatus"]:checked').val();
			const food2 = parseInt(food);

			const duration = $('#duration').val();
			const duration2 = parseInt(duration);

			const total_fee = (fpm2 + (food2 == 1 ? 20 : 0)) * duration2;
			console.log(total_fee);

			$('#t_fee').val(total_fee > 0 ? total_fee : 0);
		}

		function validatecontact() {
			var a = document.getElementById('econtact').value;
			$('#econtact').keyup(function() {
				this.value = this.value.replace(/[^0-9\.]/g, '');
				if (!this.value.match(/^\d{10}$/)) {
					$('#s1').text('please enter valid phone number')
					$('#s1').show();
				} else {
					$('#s1').hide();
				}
			});
		}

		function validatecontact2() {
			var a = document.getElementById('gcontact').value;
			$('#gcontact').keyup(function() {
				this.value = this.value.replace(/[^0-9\.]/g, '');
				if (!this.value.match(/^\d{10}$/)) {
					$('#s2').text('please enter valid phone number')
					$('#s2').show();
				} else {
					$('#s2').hide();
				}
			});
		}

		function validStrInput() {
			var a = document.getElementById('gname').value;
			$('#gname').keyup(function() {
				this.value = this.value.replace(/[^a-zA-Z_ ]/g, '');
			});
		}

		function validStrInput2() {
			var a = document.getElementById('grelation').value;
			$('#grelation').keyup(function() {
				this.value = this.value.replace(/[^a-zA-Z_ ]/g, '');
			});
		}

		function validPincode() {
			var a = document.getElementById('pincode').value;
			$('#pincode').keyup(function() {
				this.value = this.value.replace(/[^0-9\.]/g, '');
			});
		}

		function validPincode2() {
			var a = document.getElementById('ppincode').value;
			$('#ppincode').keyup(function() {
				this.value = this.value.replace(/[^0-9\.]/g, '');
			});
		}
	</script>

</head>

<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h2 class="page-title">Registration </h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill all Info</div>
									<div class="panel-body">
										<form method="post" action="" class="form-horizontal">
											<?php
											$uid = $_SESSION['login'];
											$stmt = $mysqli->prepare("SELECT emailid FROM registration WHERE emailid=? || regno=? ");
											$stmt->bind_param('ss', $uid, $uid);
											$stmt->execute();
											$stmt->bind_result($email);
											$rs = $stmt->fetch();
											$stmt->close();
											if ($rs) { ?>
												<h3 style="color: red" align="center">Hostel already booked by you</h3>
												<div align="center">
													<div class="col-md-4">&nbsp;</div>
													<div class="col-md-4">
														<div class="panel panel-default">
															<div class="panel-body bk-success text-light">
																<div class="stat-panel text-center">

																	<div class="stat-panel-number h1 ">My Room</div>

																</div>
															</div>
															<a href="room-details.php" class="block-anchor panel-footer text-center">See All &nbsp; <i class="fa fa-arrow-right"></i></a>
														</div>
													</div>
												</div>
											<?php } else {

											?>
												<div class="form-group">
													<label class="col-sm-4 control-label">
														<h4 style="color: green" align="left">Room Related info </h4>
													</label>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Room no. </label>
													<div class="col-sm-8">
														<select name="room" id="room" class="form-control" onChange="getSeater(this.value);getTotal();" onBlur="checkAvailability()" required>
															<option value="">Select Room</option>
															<?php $query = "SELECT * FROM rooms";
															$stmt2 = $mysqli->prepare($query);
															$stmt2->execute();
															$res = $stmt2->get_result();
															while ($row = $res->fetch_object()) {
															?>
																<option value="<?php echo $row->room_no; ?>"> <?php echo $row->room_no; ?></option>
															<?php } ?>
														</select>
														<div style="margin-top: 10px;"><span id="room-availability-status"></span></div>

													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Seater</label>
													<div class="col-sm-8">
														<input type="text" name="seater" id="seater" class="form-control" readonly="true">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Fees Per Month</label>
													<div class="col-sm-8">
														<input type="text" name="fpm" id="fpm" class="form-control" readonly="true">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Food Status</label>
													<div class="col-sm-8">
														<input type="radio" value="0" id="f1" name="foodstatus" checked="checked" onClick="getTotal()"> Without Food
														<input type="radio" value="1" id="f1" name="foodstatus" onClick="getTotal()"> With Food($ 20.00 Per Month Extra)
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Stay From</label>
													<div class="col-sm-8">
														<input type="date" name="stayf" id="stayf" class="form-control">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Duration</label>
													<div class="col-sm-8">
														<select name="duration" id="duration" class="form-control" onchange="getTotal()">
															<option value="">Select Duration in Month</option>
															<option value="1">1</option>
															<option value="2">2</option>
															<option value="3">3</option>
															<option value="4">4</option>
															<option value="5">5</option>
															<option value="6">6</option>
															<option value="7">7</option>
															<option value="8">8</option>
															<option value="9">9</option>
															<option value="10">10</option>
															<option value="11">11</option>
															<option value="12">12</option>
														</select>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Total Fee : </label>
													<div class="col-sm-8">
														<input type="text" name="t_fee" id="t_fee" class="form-control" readonly="true">
													</div>
												</div>



												<div class="form-group">
													<label class="col-sm-2 control-label">
														<h4 style="color: green" align="left">Personal info </h4>
													</label>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">course </label>
													<div class="col-sm-8">
														<select name="course" id="course" class="form-control" required>
															<option value="">Select Course</option>
															<?php $query = "SELECT * FROM courses";
															$stmt2 = $mysqli->prepare($query);
															$stmt2->execute();
															$res = $stmt2->get_result();
															while ($row = $res->fetch_object()) {
															?>
																<option value="<?php echo $row->course_fn; ?>"><?php echo $row->course_fn; ?>&nbsp;&nbsp;(<?php echo $row->course_sn; ?>)</option>
															<?php } ?>
														</select>
													</div>
												</div>

												<?php
												$aid = $_SESSION['id'];
												$ret = "select * from userregistration where id=?";
												$stmt = $mysqli->prepare($ret);
												$stmt->bind_param('i', $aid);
												$stmt->execute(); //ok
												$res = $stmt->get_result();
												//$cnt=1;
												while ($row = $res->fetch_object()) {
												?>

													<div class="form-group">
														<label class="col-sm-2 control-label">Registration No : </label>
														<div class="col-sm-8">
															<input type="text" name="regno" id="regno" class="form-control" value="<?php echo $row->regNo; ?>" readonly>
														</div>
													</div>


													<div class="form-group">
														<label class="col-sm-2 control-label">First Name : </label>
														<div class="col-sm-8">
															<input type="text" name="fname" id="fname" class="form-control" value="<?php echo $row->firstName; ?>" readonly>
														</div>
													</div>

													<div class="form-group">
														<label class="col-sm-2 control-label">Middle Name : </label>
														<div class="col-sm-8">
															<input type="text" name="mname" id="mname" class="form-control" value="<?php echo $row->middleName; ?>" readonly>
														</div>
													</div>

													<div class="form-group">
														<label class="col-sm-2 control-label">Last Name : </label>
														<div class="col-sm-8">
															<input type="text" name="lname" id="lname" class="form-control" value="<?php echo $row->lastName; ?>" readonly>
														</div>
													</div>

													<div class="form-group">
														<label class="col-sm-2 control-label">Gender : </label>
														<div class="col-sm-8">
															<input type="text" name="gender" value="<?php echo $row->gender; ?>" class="form-control" readonly>
														</div>
													</div>

													<div class="form-group">
														<label class="col-sm-2 control-label">Contact No : </label>
														<div class="col-sm-8">
															<input type="text" name="contact" id="contact" value="<?php echo $row->contactNo; ?>" class="form-control" readonly>
														</div>
													</div>


													<div class="form-group">
														<label class="col-sm-2 control-label">Email id : </label>
														<div class="col-sm-8">
															<input type="email" name="email" id="email" class="form-control" value="<?php echo $row->email; ?>" readonly>
														</div>
													</div>
												<?php } ?>
												<div class="form-group">
													<label class="col-sm-2 control-label">Emergency Contact: </label>
													<div class="col-sm-8">
														<input type="text" name="econtact" id="econtact" class="form-control" required="required" onkeyup="validatecontact()">
														<div style="margin-top:10px;">
															<span style="color:red;" id="s1"><span>
														</div>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Guardian Name : </label>
													<div class="col-sm-8">
														<input type="text" name="gname" id="gname" class="form-control" required="required" onkeyup="validStrInput()">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Guardian Relation : </label>
													<div class="col-sm-8">
														<input type="text" name="grelation" id="grelation" class="form-control" required="required" onkeyup="validStrInput2()">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Guardian Contact no : </label>
													<div class="col-sm-8">
														<input type="text" name="gcontact" id="gcontact" class="form-control" required="required" onkeyup="validatecontact2()">
														<div style="margin-top:10px;">
															<span style="color:red;" id="s2"><span>
														</div>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-3 control-label">
														<h4 style="color: green" align="left">Correspondense Address </h4>
													</label>
												</div>


												<div class="form-group">
													<label class="col-sm-2 control-label">Address : </label>
													<div class="col-sm-8">
														<textarea rows="5" name="address" id="address" class="form-control" required="required"></textarea>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">City : </label>
													<div class="col-sm-8">
														<input type="text" name="city" id="city" class="form-control" required="required">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">State </label>
													<div class="col-sm-8">
														<select name="state" id="state" class="form-control" required>
															<option value="">Select State</option>
															<?php $query = "SELECT * FROM states";
															$stmt2 = $mysqli->prepare($query);
															$stmt2->execute();
															$res = $stmt2->get_result();
															while ($row = $res->fetch_object()) {
															?>
																<option value="<?php echo $row->State; ?>"><?php echo $row->State; ?></option>
															<?php } ?>
														</select>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Pincode : </label>
													<div class="col-sm-8">
														<input type="text" name="pincode" id="pincode" class="form-control" required="required" onkeyup="validPincode()">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-3 control-label">
														<h4 style="color: green" align="left">Permanent Address </h4>
													</label>
												</div>


												<div class="form-group">
													<label class="col-sm-5 control-label">Permanent Address same as Correspondense address : </label>
													<div class="col-sm-4">
														<input type="checkbox" name="adcheck" value="1" />
													</div>
												</div>


												<div class="form-group">
													<label class="col-sm-2 control-label">Address : </label>
													<div class="col-sm-8">
														<textarea rows="5" name="paddress" id="paddress" class="form-control" required="required"></textarea>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">City : </label>
													<div class="col-sm-8">
														<input type="text" name="pcity" id="pcity" class="form-control" required="required">
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">State </label>
													<div class="col-sm-8">
														<select name="pstate" id="pstate" class="form-control" required>
															<option value="">Select State</option>
															<?php $query = "SELECT * FROM states";
															$stmt2 = $mysqli->prepare($query);
															$stmt2->execute();
															$res = $stmt2->get_result();
															while ($row = $res->fetch_object()) {
															?>
																<option value="<?php echo $row->State; ?>"><?php echo $row->State; ?></option>
															<?php } ?>
														</select>
													</div>
												</div>

												<div class="form-group">
													<label class="col-sm-2 control-label">Pincode : </label>
													<div class="col-sm-8">
														<input type="text" name="ppincode" id="ppincode" class="form-control" required="required" onkeyup="validPincode2()">
													</div>
												</div>

												<div class="col-sm-6 col-sm-offset-4">
													<button class="btn btn-default" type="Reset">Reset</button>
													<input type="submit" name="submit" Value="Register & Pay" class="btn btn-primary" id="reg_id">
												</div>
										</form>
									<?php } ?>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	<script src="js2/jquery.min.js"></script>
	<script src="js2/bootstrap-select.min.js"></script>
	<script src="js2/bootstrap.min.js"></script>
	<script src="js2/jquery.dataTables.min.js"></script>
	<script src="js2/dataTables.bootstrap.min.js"></script>
	<script src="js2/fileinput.js"></script>
	<script src="js2/main.js"></script>
</body>
<script type="text/javascript">
	$(document).ready(function() {
		$('input[type="checkbox"]').click(function() {
			if ($(this).prop("checked") == true) {
				$('#paddress').val($('#address').val());
				$('#pcity').val($('#city').val());
				$('#pstate').val($('#state').val());
				$('#ppincode').val($('#pincode').val());
			}

		});
	});
</script>
<script>
	function checkAvailability() {
		$("#loaderIcon").show();
		jQuery.ajax({
			url: "check_availability.php",
			data: 'roomno=' + $("#room").val(),
			type: "POST",
			success: function(data) {
				$("#loaderIcon").hide();
				console.log(data)
				if (data == "<span style='color:red;font-size:17px'>No Seats Available</span>") {
					$("#reg_id").hide();
				} else {
					$("#reg_id").show();
				}
				$("#room-availability-status").html(data);
			},
			error: function() {}
		});
	}
</script>


<script type="text/javascript">
	$(document).ready(function() {
		$('#duration').keyup(function() {
			var fetch_dbid = $(this).val();
			$.ajax({
				type: 'POST',
				url: "ins-amt.php?action=userid",
				data: {
					userinfo: fetch_dbid
				},
				success: function(data) {
					$('.result').val(data);
				}
			});


		})
	});
</script>

</html>