<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include('includes/config.php');
if (isset($_POST['submit'])) {
	// print_r($_POST);
	// die;
	$regno = $_POST['regno'];
	$fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$lname = $_POST['lname'];
	$gender = $_POST['gender'];
	$contactno = $_POST['contact'];
	$emailid = $_POST['email'];
	$password = $_POST['password'];
	// $result = $mysqli->query("SELECT count(*) as cnt FROM userregistration WHERE email='{$emailid}' or regNo='{$regno}' limit 1");
	// $res = $result->fetch_array();
	// print_r($res['cnt']);
	// die;
	$result = "SELECT count(*) FROM userregistration WHERE email=? || regNo=?";
	$stmt = $mysqli->prepare($result);
	$stmt->bind_param('ss', $emailid, $regno);
	$stmt->execute();
	$stmt->bind_result($count);
	$stmt->fetch();
	$stmt->close();
	if ($count > 0) {
		echo "<script>alert('Registration number or email id already registered.');</script>";
	} else {

		$query = "insert into  userregistration(regNo,firstName,middleName,lastName,gender,contactNo,email,password) values(?,?,?,?,?,?,?,?)";
		$stmt = $mysqli->prepare($query);
		$rc = $stmt->bind_param('sssssiss', $regno, $fname, $mname, $lname, $gender, $contactno, $emailid, $password);
		$stmt->execute();
		echo "<script>alert('Student Succssfully register');</script>";
	}
	header("location:registration.php");
}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>User Registration</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Student Hostel Registration</title>
	<link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
	<link rel="manifest" href="favicon.ico/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">

	<link rel="stylesheet" href="css2/font-awesome.min.css">
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css2/bootstrap-social.css">
	<link rel="stylesheet" href="css2/bootstrap-select.css">
	<link rel="stylesheet" href="css2/fileinput.min.css">
	<link rel="stylesheet" href="css2/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css2/style.css">

	<script type="text/javascript" src="js2/jquery-1.11.3-jquery.min.js"></script>
	<script type="text/javascript" src="js2/validation.min.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	<script type="text/javascript">
		function valid() {
			if (document.registration.password.value != document.registration.cpassword.value) {
				alert("Password and Re-Type Password Field do not match  !!");
				document.registration.cpassword.focus();
				return false;
			}
			return true;
		}

		function validpsswd(msg) {
			var str = document.getElementById("password").value;
			if (!str.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/g)) {
				$('#s1').text(msg);
				$('#s1').show();
				$('#register').attr('disabled', 'disabled');
			} else {
				$('#s1').hide();
				$('#register').removeAttr('disabled', 'disabled');
			}
		}

		function validatecontact() {
			var a = document.getElementById('contact').value;
			$('#contact').keyup(function() {
				this.value = this.value.replace(/[^0-9\.]/g, '');
				if (!this.value.match(/^\d{10}$/)) {
					$('#s2').text('please enter valid phone number')
					$('#s2').show();
				} else {
					$('#s2').hide();
				}
			});
		}

		function validreg() {
			var a = document.getElementById('regno').value;
			$('#regno').keyup(function() {
				this.value = this.value.replace(/[^0-9\.]/g, '');
			});
		}

		function validStrInput() {
			// this is for FirstName
			var a = document.getElementById('fname').value;
			$('#fname').keyup(function() {
				this.value = this.value.replace(/[^a-zA-Z_ ]/g, '');
			});
		}

		function validStrInput2() {
			// this is for middleName
			var a = document.getElementById('mname').value;
			$('#mname').keyup(function() {
				this.value = this.value.replace(/[^a-zA-Z_ ]/g, '');
			});
		}

		function validStrInput3() {
			// this is for lastName
			var a = document.getElementById('lname').value;
			$('#lname').keyup(function() {
				this.value = this.value.replace(/[^a-zA-Z_ ]/g, '');
			});
		}
	</script>
</head>

<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h2 class="page-title">Student Registration </h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Fill all Info</div>
									<div class="panel-body">
										<form method="post" action="" name="registration" class="form-horizontal" onSubmit="return valid();">



											<div class="form-group">
												<label class="col-sm-2 control-label"> Registration No : </label>
												<div class="col-sm-8">
													<input type="text" name="regno" id="regno" class="form-control" required="required" onBlur="checkRegnoAvailability()" onkeyup="validreg()">
													<span id="user-reg-availability" style="font-size:12px;"></span>
												</div>
											</div>


											<div class="form-group">
												<label class="col-sm-2 control-label">First Name : </label>
												<div class="col-sm-8">
													<input type="text" name="fname" id="fname" class="form-control" required="required" onkeyup="validStrInput()">
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Middle Name : </label>
												<div class="col-sm-8">
													<input type="text" name="mname" id="mname" class="form-control" onkeyup="validStrInput2()">
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Last Name : </label>
												<div class="col-sm-8">
													<input type="text" name="lname" id="lname" class="form-control" required="required" onkeyup="validStrInput3()">
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Gender : </label>
												<div class="col-sm-8">
													<select name="gender" class="form-control" required="required">
														<option value="">Select Gender</option>
														<option value="male">Male</option>
														<option value="female">Female</option>
														<option value="others">Others</option>
													</select>
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Contact No : </label>
												<div class="col-sm-8">
													<input type="text" name="contact" id="contact" class="form-control" required="required" onkeyup="validatecontact()">
													<div style="margin-top:10px;">
														<span style="color:red;" id="s2"><span>
													</div>

												</div>
											</div>


											<div class="form-group">
												<label class="col-sm-2 control-label">Email id: </label>
												<div class="col-sm-8">
													<input type="email" name="email" id="email" class="form-control" onBlur="checkAvailability()" required="required">
													<span id="user-availability-status" style="font-size:12px;"></span>
												</div>
											</div>

											<div class="form-group">
												<label class="col-sm-2 control-label">Password: </label>
												<div class="col-sm-8">
													<input type="password" name="password" id="password" class="form-control" required="required" onkeyup="validpsswd('Password Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters')">
													<div style="margin-top:10px;">
														<span style="color:red;" id="s1"><span>
													</div>
												</div>
											</div>


											<div class="form-group">
												<label class="col-sm-2 control-label">Confirm Password : </label>
												<div class="col-sm-8">
													<input type="password" name="cpassword" id="cpassword" class="form-control" required="required">
												</div>
											</div>




											<div class="col-sm-6 col-sm-offset-4">
												<button class="btn btn-default" type="reset">Reset</button>
												<input type="submit" name="submit" Value="Register" class="btn btn-primary" id="register">
											</div>
										</form>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	<script src="js2/jquery.min.js"></script>
	<script src="js2/bootstrap-select.min.js"></script>
	<script src="js2/bootstrap.min.js"></script>
	<script src="js2/jquery.dataTables.min.js"></script>
	<script src="js2/dataTables.bootstrap.min.js"></script>
	<script src="js2/Chart.min.js"></script>
	<script src="js2/fileinput.js"></script>
	<script src="js2/chartData.js"></script>
	<script src="js2/main.js"></script>
</body>
<script>
	function checkAvailability() {

		$("#loaderIcon").show();
		jQuery.ajax({
			url: "check_availability.php",
			data: 'emailid=' + $("#email").val(),
			type: "POST",
			success: function(data) {
				$("#user-availability-status").html(data);
				$("#loaderIcon").hide();
			},
			error: function() {
				event.preventDefault();
				// alert('error');
			}
		});
	}
</script>
<script>
	function checkRegnoAvailability() {

		$("#loaderIcon").show();
		jQuery.ajax({
			url: "check_availability.php",
			data: 'regno=' + $("#regno").val(),
			type: "POST",
			success: function(data) {
				$("#user-reg-availability").html(data);
				$("#loaderIcon").hide();
			},
			error: function() {
				event.preventDefault();
				// alert('error');
			}
		});
	}
</script>

</html>