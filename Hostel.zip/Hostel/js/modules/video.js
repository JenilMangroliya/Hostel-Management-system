"use strict";

import YouTubePlayer from "youtube-player";

function setYTFrame() {
  const trigger = document.querySelector(".video-play");
  const popup = document.querySelector(".video");
  const playerElem = document.querySelector("#player");

  if (playerElem) {
    let player;
    player = YouTubePlayer("player");
    player.loadVideoById("ixIzimI35SE");
    player.stopVideo();

    if (popup) {
      document.body.addEventListener("click", (e) => {
        if (e.target !== null) {
          if (popup.classList.contains("visible")) {
            if (e.target !== playerElem) {
              popup.classList.remove("visible", "fadeIn");
              popup.classList.add("fadeOut");
              player.stopVideo();
            }
          } else if (
            e.target === trigger ||
            (e.target.closest("a") !== null &&
              e.target.closest("a").classList.contains("video-play"))
          ) {
            e.preventDefault();
            popup.classList.remove("fadeOut");
            popup.classList.add("visible", "fadeIn");
          }
        }
      });
    }
  }
}

export default setYTFrame;
