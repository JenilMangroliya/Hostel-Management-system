"use strict";

// const _KEY = "AIzaSyA_C-z1hi09X8PLNpyXF-Y_hO3CGqZcScA";

// import { Loader } from "@googlemaps/js-api-loader";
// import mapTheme from "./map-theme";

function initMap() {
  // const uluru = { lat: 21.1412111, lng: 72.7937591 };
  // // The map, centered at Uluru
  // const map = new google.maps.Map(document.getElementById("map"), {
  //   zoom: 16,
  //   center: uluru,
  // });
  // // The marker, positioned at Uluru
  // const marker = new google.maps.Marker({
  //   position: uluru,
  //   map: map,
  // });
  // const loader = new Loader({
  //   apiKey: _KEY,
  //   version: "weekly",
  // });
  // const mapContainer = document.querySelector("#map");
  // const defaultMarker = { lat: 21.1412111, lng: 72.7937591 };
  // loader.load().then(() => {
  //   const map = new google.maps.Map(mapContainer, {
  //     center: defaultMarker,
  //     zoom: 16,
  //     styles: [...mapTheme],
  //     disableDefaultUI: true,
  //   });
  //   const marker = new google.maps.Marker({
  //     position: defaultMarker,
  //     map: map,
  //     icon: "./svg/marker.svg",
  //   });
  // });
}

export default initMap;
