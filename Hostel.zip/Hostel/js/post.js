"use strict";

import initGallery from "./modules/gallery";

document.addEventListener("DOMContentLoaded", () => {
  initGallery(".post_main-article_gallery");
});
