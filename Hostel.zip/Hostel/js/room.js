"use strict";

import initProgressbar from "./modules/progress";
import { initSwiperSlider } from "./modules/slider";

document.addEventListener("DOMContentLoaded", () => {
  initProgressbar(".room_main .rating");
  initSwiperSlider(".room_main-slider_thumbs", {
    slidesPerView: 2,
    spaceBetween: 15,
    loop: true,
    watchSlidesProgress: true,
    autoplay: true,
    speed: 1500,
    breakpoints: {
      768: {
        spaceBetween: 30,
      },
    },
  });
  swiperChangeableDirection();
  initSwiperSlider(".room_main-slider_view", {
    slidesPerView: 1,
    effect: "fade",
    crossFade: true,
    loop: true,
    thumbs: document.querySelector(".room_main-slider_thumbs").swiper,
    autoplay: true,
    speed: 1500,
  });

  window.addEventListener("resize", swiperChangeableDirection);
});

function swiperChangeableDirection() {
  const thumbsInstance = document.querySelector(
    ".room_main-slider_thumbs"
  ).swiper;

  if (window.innerWidth < 991.98) {
    thumbsInstance.changeDirection("horizontal");
  } else {
    thumbsInstance.changeDirection("vertical");
  }
}
