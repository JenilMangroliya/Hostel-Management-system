<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PayPal\Api\Amount;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Api\ItemList;

require 'config2.php';
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();


$AID = $_SESSION['id'];
// echo "select feespm,duration,foodstatus,roomno from registration where regno={$AID} ";
$result = $mysqli->query("select id,regNo from userregistration where id={$AID}");
$res = $result->fetch_array();
// print_r($res);
// die;
$result = $mysqli->query("select id,feespm,duration,foodstatus,roomno from registration where regno={$res['regNo']}");
$res = $result->fetch_array();
// print_r($res);
// die;
$_SESSION['PayPal_order_id'] = $res['id'];


// print_r($res['feespm']);
// die;
// print_r($res['duration']);
// die;
// print_r($res['foodstatus']);
// die;


$R = $res['roomno'];
// print_r($R);
// die;
$fee = $res['feespm'] * $res['duration'];
// print_r($fee);
// die;
// $room_id = isset($res['id']);
if (isset($res['foodstatus']) == 1) {
    $f_fee = 20 * $res['duration'];
} else {
    $f_fee = 0;
}
$total_fee = $fee + $f_fee;
// print_r($total_fee);
// die;

// if (isset($_POST[$res['duration']])) {
//     throw new Exception('This script should not be called directly, expected post data');
// }

$payer = new Payer();
$payer->setPaymentMethod('paypal');

// Set some example data for the payment.
$currency = 'USD';
$item_qty = 1;
$amountPayable = $total_fee;
$product_name = "room no: " . $R;
$item_code = 1;
$description = 'Paypal transaction';
$invoiceNumber = uniqid();
$my_items = array(
    array('name' => $product_name, 'quantity' => $item_qty, 'price' => $amountPayable, 'sku' => $item_code, 'currency' => $currency)
);

$amount = new Amount();
$amount->setCurrency($currency)
    ->setTotal($amountPayable);

$items = new ItemList();
$items->setItems($my_items);

$transaction = new Transaction();
$transaction->setAmount($amount)
    ->setDescription($description)
    ->setInvoiceNumber($invoiceNumber)
    ->setItemList($items);

$redirectUrls = new RedirectUrls();
$redirectUrls->setReturnUrl($paypalConfig['return_url'])
    ->setCancelUrl($paypalConfig['cancel_url']);

$payment = new Payment();
$payment->setIntent('sale')
    ->setPayer($payer)
    ->setTransactions([$transaction])
    ->setRedirectUrls($redirectUrls);

try {
    $payment->create($apiContext);
} catch (Exception $e) {
    throw new Exception('Unable to create link for payment');
}

header('location:' . $payment->getApprovalLink());
exit(1);
