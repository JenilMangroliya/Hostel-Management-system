<?php
session_start();
include('includes/config.php');
if (isset($_POST['login'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];
	$stmt = $mysqli->prepare("SELECT email,password,id FROM userregistration WHERE email=? and password=? ");
	$stmt->bind_param('ss', $email, $password);
	$stmt->execute();
	$stmt->bind_result($email, $password, $id);
	$rs = $stmt->fetch();
	$stmt->close();
	$_SESSION['id'] = $id;
	$_SESSION['login'] = $email;
	$uip = $_SERVER['REMOTE_ADDR'];
	$ldate = date('d/m/Y h:i:s', time());
	if ($rs) {
		$uid = $_SESSION['id'];
		$uemail = $_SESSION['login'];
		$ip = $_SERVER['REMOTE_ADDR'];
		$geopluginURL = 'http://www.geoplugin.net/php.gp?ip=' . $ip;
		$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
		$city = $addrDetailsArr['geoplugin_city'];
		$country = $addrDetailsArr['geoplugin_countryName'];
		$log = "insert into userLog(userId,userEmail,userIp,city,country) values('$uid','$uemail','$ip','$city','$country')";
		$mysqli->query($log);
		if ($log) {
			header("location:dashboard.php");
		}
	} else {
		echo "<script>alert('Invalid Username/Email or password');</script>";
	}
}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Student Hostel Registration</title>
	<link rel="stylesheet" href="css2/font-awesome.min.css">
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/dataTables.bootstrap.min.css">>
	<link rel="stylesheet" href="css2/bootstrap-social.css">
	<link rel="stylesheet" href="css2/bootstrap-select.css">
	<link rel="stylesheet" href="css2/fileinput.min.css">
	<link rel="stylesheet" href="css2/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css2/style.css">
	<link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
	<link rel="manifest" href="favicon.ico/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<script type="text/javascript" src="js2/jquery-1.11.3-jquery.min.js"></script>
	<script type="text/javascript" src="js2/validation.min.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
	<script type="text/javascript">
		function valid() {
			if (document.registration.password.value != document.registration.cpassword.value) {
				alert("Password and Re-Type Password Field do not match  !!");
				document.registration.cpassword.focus();
				return false;
			}
			return true;
		}
	</script>
</head>

<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h2 class="page-title">User Login </h2>

						<div class="row">
							<div class="col-md-6 col-md-offset-3">
								<div class="well row pt-2x pb-3x bk-light">
									<div class="col-md-8 col-md-offset-2">

										<form action="" class="mt" method="post">
											<label for="" class="text-uppercase text-sm">Email</label>
											<input type="text" placeholder="Email" name="email" class="form-control mb">
											<label for="" class="text-uppercase text-sm">Password</label>
											<input type="password" placeholder="Password" name="password" class="form-control mb">


											<input type="submit" name="login" class="btn btn-primary btn-block" value="login">
										</form>
									</div>
								</div>
								<div class="text-center text-light">
									<a href="forgot-password.php" class="text-light">Forgot password?</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	<script src="js2/jquery.min.js"></script>
	<script src="js2/bootstrap-select.min.js"></script>
	<script src="js2/bootstrap.min.js"></script>
	<script src="js2/jquery.dataTables.min.js"></script>
	<script src="js2/dataTables.bootstrap.min.js"></script>
	<script src="js2/Chart.min.js"></script>
	<script src="js2/fileinput.js"></script>
	<script src="js2/chartData.js"></script>
	<script src="js2/main.js"></script>
</body>

</html>