<?php
require_once('SMTP.php');
require_once('PHPMailer.php');
require_once('Exception.php');

use \PHPMailer\PHPMailer\PHPMailer;
use \PHPMailer\PHPMailer\Exception;

if (isset($_POST['submit'])) {
    // print_r($_POST['submit']);
    // die;
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    // print_r($_POST);
    // die;
    $mail = new PHPMailer(true); // Passing `true` enables exceptions
    try {
        // //settings
        $mail->isSMTP();
        $mail->SMTPDebug = 0; // if we want to print message than set SMTPDebug=2;
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "tls";
        $mail->Port = 587;
        $mail->CharSet = "UTF-8";

        $mail->Username = ''; // SMTP username  means your gmail id or account you want to use as host to send mail
        $mail->Password = ''; // SMTP password your gmail id or account password

        $mail->setFrom($email, $name);

        //recipient
        $mail->addAddress('');     // Add a recipient means whomever you want send or display

        //content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body =  $message;
        $mail->AltBody = '<p>This is the body in plain text for non-HTML mail clients</p>';

        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo 'Message could not be sent.<br>';
        // echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
    header("location:contacts.php");
}
