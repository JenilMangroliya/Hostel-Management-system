<?php
session_start();
include('includes/config.php');
if (isset($_POST['login'])) {
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	$stmt = $mysqli->prepare("SELECT email,contactNo,password FROM userregistration WHERE (email=? && contactNo=?) ");
	$stmt->bind_param('ss', $email, $contact);
	$stmt->execute();
	$stmt->bind_result($username, $email, $password);
	$rs = $stmt->fetch();
	if ($rs) {
		$pwd = $password;
	} else {
		echo "<script>alert('Invalid Email/Contact no or password');</script>";
	}
}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>User Forgot Password</title>

	<link rel="stylesheet" href="css2/font-awesome.min.css">
	<link rel="stylesheet" href="css2/bootstrap.min.css">
	<link rel="stylesheet" href="css2/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css2/bootstrap-social.css">
	<link rel="stylesheet" href="css2/bootstrap-select.css">
	<link rel="stylesheet" href="css2/fileinput.min.css">
	<link rel="stylesheet" href="css2/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css2/style.css">
	<link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
	<link rel="manifest" href="favicon.ico/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
</head <body>

<div class="login-page bk-img" style="background-image: url(img/about/02.jpg);">
	<div class="form-content">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<h1 class="text-center text-bold text-light mt-4x">Forgot Password</h1>
					<div class="well row pt-2x pb-3x bk-light">
						<div class="col-md-8 col-md-offset-2">
							<?php if (isset($_POST['login'])) { ?>
								<p>Yuor Password is <?php echo $pwd; ?><br> Change the Password After login</p>
							<?php }  ?>
							<form action="" class="mt" method="post">
								<label for="" class="text-uppercase text-sm">Your Email</label>
								<input type="email" placeholder="Email" name="email" class="form-control mb">
								<label for="" class="text-uppercase text-sm">Your Contact no</label>
								<input type="text" placeholder="Contact no" name="contact" class="form-control mb">


								<input type="submit" name="login" class="btn btn-primary btn-block" value="login">
							</form>
						</div>
					</div>
					<div class="text-center text-light">
						<a href="index2.php" class="text-light">Sign in?</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="js2/jquery.min.js"></script>
<script src="js2/bootstrap-select.min.js"></script>
<script src="js2/bootstrap.min.js"></script>
<script src="js2/jquery.dataTables.min.js"></script>
<script src="js2/dataTables.bootstrap.min.js"></script>
<script src="js2/Chart.min.js"></script>
<script src="js2/fileinput.js"></script>
<script src="js2/chartData.js"></script>
<script src="js2/main.js"></script>
</body>

</html>