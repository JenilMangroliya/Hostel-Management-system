<?php

namespace Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
