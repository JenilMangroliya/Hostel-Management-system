// Your database details

<?php
$dbuser = "";
$dbpass = "";
$host = "";
$db = "";
$mysqli = new mysqli($host, $dbuser, $dbpass, $db);
