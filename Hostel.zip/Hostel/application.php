<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

if (isset($_POST['submit'])) {
    // print_r($_POST);
    // die;

    $regno = $_POST['regno'];
    $type = $_POST['type'];
    $message = filter_var(htmlspecialchars(htmlentities(trim(preg_replace("/\r|\n/", "", $_POST['message'])), ENT_QUOTES), FILTER_SANITIZE_SPECIAL_CHARS));
    $subject = $_POST['subject'];

    $query = "insert into enquiry(userid,type,message,subject) values(?,?,?,?)";
    $stmt = $mysqli->prepare($query);
    $rc = $stmt->bind_param('isss', $_SESSION['id'], $type, $message, $subject);
    $stmt->execute();
    header("location:application.php");
    // print_r($stmt);
    // die;
}

?>
<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">
    <title>Enquiry-List</title>
    <link rel="stylesheet" href="css2/font-awesome.min.css">
    <link rel="stylesheet" href="css2/bootstrap.min.css">
    <link rel="stylesheet" href="css2/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css2/bootstrap-social.css">
    <link rel="stylesheet" href="css2/bootstrap-select.css">
    <link rel="stylesheet" href="css2/fileinput.min.css">
    <link rel="stylesheet" href="css2/awesome-bootstrap-checkbox.css">
    <link rel="stylesheet" href="css2/style.css">
    <link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
    <link rel="manifest" href="favicon.ico/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <script language="javascript" type="text/javascript">
        var popUpWin = 0;

        function popUpWindow(URLStr, left, top, width, height) {
            if (popUpWin) {
                if (!popUpWin.closed) popUpWin.close();
            }
            popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width=' + 510 + ',height=' + 430 + ',left=' + left + ', top=' + top + ',screenX=' + left + ',screenY=' + top + '');
        }
    </script>
    <?php
    $aid = $_SESSION['id'];
    $ret = "select * from enquiry where userid=?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('i', $aid);
    $stmt->execute(); //ok
    $res2 = $stmt->get_result();

    $res2 = $res2->fetch_all(MYSQLI_ASSOC);

    ?>
    <script>
        var res = JSON.parse('<?= json_encode($res2) ?>');

        function showMessage(index) {
            index = parseInt(index);
            $('#modal_des2').html("Message :" + res[index].message);
        }
    </script>
</head>

<body>
    <?php include('includes/header.php'); ?>

    <div class="ts-main-content">
        <?php include('includes/sidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="page-title" style="margin-top:4%">Your Application </h2>
                        <div class="panel panel-default">
                            <div class="panel-heading">Application History
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal" style="margin-left:84%;font-size: 15px;">
                                    New Application <i class="fa fa-plus-square"></i>
                                </button>

                                <!-- The Modal -->
                                <div class="modal" id="myModal">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">
                                                    &times;
                                                </button>
                                            </div>
                                            <div class="container-fluid">

                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <h2 class="page-title">File Application</h2>

                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="panel panel-primary">
                                                                    <div class="panel-heading">Fill all Info</div>
                                                                    <div class="panel-body">
                                                                        <form method="post" action="" name="registration" class="form-horizontal">
                                                                            <?php
                                                                            $aid = $_SESSION['id'];
                                                                            $ret = "select * from userregistration where id=?";
                                                                            $stmt = $mysqli->prepare($ret);
                                                                            $stmt->bind_param('i', $aid);
                                                                            $stmt->execute(); //ok
                                                                            $res = $stmt->get_result();
                                                                            //$cnt=1;
                                                                            while ($row = $res->fetch_object()) {
                                                                            ?>

                                                                                <div class=" form-group">
                                                                                    <label class="col-sm-3 control-label">Registration No : </label>
                                                                                    <div class="col-sm-9">
                                                                                        <input type="text" name="regno" id="regno" class="form-control" value="<?php echo $row->regNo; ?>" readonly>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="form-group">
                                                                                    <label class="col-sm-2 control-label"> Name : </label>
                                                                                    <div class="col-sm-10">
                                                                                        <input type="text" name="name" id="name" class="form-control" value="<?php echo $row->firstName ?> <?php echo $row->middleName ?> <?php echo $row->lastName ?> " readonly>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="form-group">
                                                                                    <label class="col-sm-2 control-label">Email id : </label>
                                                                                    <div class="col-sm-10">
                                                                                        <input type="email" name="email" id="email" class="form-control" value="<?php echo $row->email; ?>" readonly>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="form-group">
                                                                                    <label class="col-sm-2 control-label">Contact : </label>
                                                                                    <div class="col-sm-10">
                                                                                        <input type="text" name="contact" id="contact" value="<?php echo $row->contactNo; ?>" class="form-control" readonly>
                                                                                    </div>
                                                                                </div>
                                                                            <?php } ?>
                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label"> Type : </label>
                                                                                <div class="col-sm-10">
                                                                                    <select name="type" class="form-control" required="required">
                                                                                        <option value="">Select Type</option>
                                                                                        <option value="leave">Leave Application</option>
                                                                                        <option value="roomchange">Room Change</option>
                                                                                        <option value="complain">Complain</option>
                                                                                        <option value="other">Other</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label">Subject : </label>
                                                                                <div class="col-sm-10">
                                                                                    <input type="text" name="subject" id="subject" class="form-control" required="required">
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label">Message : </label>
                                                                                <div class="col-sm-10">
                                                                                    <textarea rows="8" name="message" id="message" class="form-control" required="required"></textarea>
                                                                                </div>
                                                                            </div>

                                                                            <div class="col-sm-6 col-sm-offset-4">
                                                                                <button class="btn btn-default" type="reset">Reset</button>
                                                                                <input type="submit" name="submit" Value="Submit" class="btn btn-primary">
                                                                            </div>
                                                                        </form>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body" style="overflow:scroll">
                                <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Application Type</th>
                                            <th>Status</th>
                                            <th>Subject</th>
                                            <th>View</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
                                            <th>Application Type</th>
                                            <th>Status</th>
                                            <th>Subject</th>
                                            <th>View</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $aid = $_SESSION['id'];
                                        // $result = $mysqli->query("select * from enquiry where regno={$aid}");
                                        // $res = $result->fetch_assoc();
                                        $ret = "select * from enquiry where userid=?";
                                        $stmt = $mysqli->prepare($ret);
                                        $stmt->bind_param('i', $aid);
                                        $stmt->execute(); //ok
                                        $res = $stmt->get_result();
                                        $cnt = 1;
                                        $index = 0;
                                        while ($row = $res->fetch_object()) {
                                        ?>
                                            <tr>
                                                <td><?php echo $cnt;; ?></td>
                                                <td><?php echo $row->type ?></td>
                                                <td><?php if ($row->status == 0) {
                                                        echo "<span style='padding-left:2%; color:red;'><i class='fa fa-clock-o'></i> Pending !<span>";
                                                    } else if ($row->status == 1) {

                                                        echo "<span style='padding-left:2%; color:red;'> <i class='fa fa-close'></i> Your " . (($row->type == 'complain') ? 'Complain' : 'Application') . " Has Been Rejected <span>";
                                                    } else if ($row->status == 2) {
                                                        echo "<span style='padding-left:2%; color:green;'> <i class='fa fa-check'></i> Your " . (($row->type == 'complain') ? 'Complain' : 'Application') . " Has Been Accepted <span>";
                                                    } ?>
                                                </td>
                                                <td><?php echo $row->subject ?></td>

                                                <td class="text-center">
                                                    <button title="View Message" type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal1" onclick="showMessage('<?= $index ?>')"><i class="fa fa-eye" style="font-size:25px;"></i></button>&nbsp;&nbsp;

                                                </td>
                                            </tr>
                                        <?php
                                            $cnt = $cnt + 1;
                                            $index++;
                                        } ?>


                                    </tbody>
                                </table>
                                <div class="modal" id="myModal1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">
                                                    &times;
                                                </button>
                                            </div>
                                            <div class="container-fluid">

                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <h2 class="page-title">Message</h2>

                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div>

                                                                </div>
                                                                <div class="panel panel-primary">
                                                                    <div class="panel-heading" id="subject"></div>
                                                                    <div class="panel-body" style="overflow:scroll;">

                                                                        <div id="modal_des2">

                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>


                    </div>
                </div>



            </div>
        </div>
    </div>

    <!-- Loading Scripts -->
    <script src="js2/jquery.min.js"></script>
    <script src="js2/bootstrap-select.min.js"></script>
    <script src="js2/bootstrap.min.js"></script>
    <script src="js2/jquery.dataTables.min.js"></script>
    <script src="js2/dataTables.bootstrap.min.js"></script>
    <script src="js2/Chart.min.js"></script>
    <script src="js2/fileinput.js"></script>
    <script src="js2/chartData.js"></script>
    <script src="js2/main.js"></script>


</body>

</html>