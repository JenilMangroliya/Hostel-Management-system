<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Contacts | Hosteller</title>
    <script id="www-widgetapi-script" src="https://s.ytimg.com/yts/jsbin/www-widgetapi-vflS50iB-/www-widgetapi.js" async=""></script>
    <link rel="stylesheet preload" as="style" href="css/preload.min.css" />
    <link rel="stylesheet preload" as="style" href="css/libs.min.css" />

    <link rel="stylesheet" href="css/contacts.min.css" />
    <link rel="apple-touch-icon" sizes="57x57" href="favicon.ico/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon.ico/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon.ico/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon.ico/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon.ico/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon.ico/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon.ico/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon.ico/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon.ico/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon.ico/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon.ico/favicon-16x16.png">
    <link rel="manifest" href="favicon.ico/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon.ico/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <style>
        #map2 {

            height: 100%;
            width: 100%;

        }
    </style>
</head>

<body>
    <header class="header d-flex align-items-center" data-page="home">
        <div class="container position-relative d-flex justify-content-between align-items-center">
            <a class="brand d-flex align-items-center" href="index.php">
                <span class="brand_logo theme-element">
                    <svg id="brandHeader" width="22" height="23" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.03198 3.80281V7.07652L3.86083 9.75137L0.689673 12.4263L0.667474 6.56503C0.655304 3.34138 0.663875 0.654206 0.686587 0.593579C0.71907 0.506918 1.4043 0.488223 3.87994 0.506219L7.03198 0.529106V3.80281ZM21.645 4.36419V5.88433L17.0383 9.76316C14.5046 11.8966 11.2263 14.6552 9.75318 15.8934L7.07484 18.145V20.3225V22.5H3.85988H0.64502L0.667303 18.768L0.689673 15.036L2.56785 13.4609C3.60088 12.5946 6.85989 9.85244 9.81009 7.36726L15.1741 2.84867L18.4096 2.8464L21.645 2.84413V4.36419ZM21.645 15.5549V22.5H18.431H15.217V18.2638V14.0274L15.4805 13.7882C15.8061 13.4924 21.5939 8.61606 21.6236 8.61248C21.6353 8.61099 21.645 11.7351 21.645 15.5549Z" fill="currentColor" />
                    </svg>
                </span>
                <span class="brand_name">Royal</span>
            </a>
            <div class="header_offcanvas offcanvas offcanvas-end" id="menuOffcanvas">
                <div class="header_offcanvas-header d-flex justify-content-between align-content-center">
                    <a class="brand d-flex align-items-center" href="index.php">
                        <span class="brand_logo theme-element">
                            <svg id="brandOffset" width="22" height="23" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.03198 3.80281V7.07652L3.86083 9.75137L0.689673 12.4263L0.667474 6.56503C0.655304 3.34138 0.663875 0.654206 0.686587 0.593579C0.71907 0.506918 1.4043 0.488223 3.87994 0.506219L7.03198 0.529106V3.80281ZM21.645 4.36419V5.88433L17.0383 9.76316C14.5046 11.8966 11.2263 14.6552 9.75318 15.8934L7.07484 18.145V20.3225V22.5H3.85988H0.64502L0.667303 18.768L0.689673 15.036L2.56785 13.4609C3.60088 12.5946 6.85989 9.85244 9.81009 7.36726L15.1741 2.84867L18.4096 2.8464L21.645 2.84413V4.36419ZM21.645 15.5549V22.5H18.431H15.217V18.2638V14.0274L15.4805 13.7882C15.8061 13.4924 21.5939 8.61606 21.6236 8.61248C21.6353 8.61099 21.645 11.7351 21.645 15.5549Z" fill="currentColor" />
                            </svg>
                        </span>
                        <span class="brand_name">Royal</span>
                    </a>
                    <button class="close" type="button" data-bs-dismiss="offcanvas">
                        <i class="icon-close--entypo"></i>
                    </button>
                </div>
                <nav class="header_nav">
                    <ul class="header_nav-list">
                        <li class="header_nav-list_item">
                            <a class="nav-item" href="index.php" data-page="home">Home</a>
                        </li>
                        <li class="header_nav-list_item">
                            <a class="nav-item " href="about.php" data-page="about">About</a>
                        </li>
                        <li class="header_nav-list_item">
                            <a class="nav-item" href="rooms.php" data-page="about">Rooms</a>
                        </li>
                        <li class="header_nav-list_item">
                            <a class="nav-item" href="gallery.php" data-page="about">Gallery</a>
                        </li>

                        <li class="header_nav-list_item dropdown">
                            <a class="nav-link nav-link--contacts dropdown-toggle d-inline-flex align-items-center" href="contacts.php" data-bs-toggle="collapse" data-bs-target="#contactsMenu" aria-expanded="false" aria-controls="contactsMenu">
                                Contacts
                                <i class="icon-chevron_down--entypo icon"></i>
                            </a>
                            <div class="dropdown-menu collapse" id="contactsMenu">

                            </div>
                        </li>
                    </ul>
                </nav>
                <ul class="socials d-flex align-items-center">
                    <li class="list-item">
                        <a class="link" href="">
                            <i class="icon-facebook"></i>
                        </a>
                    </li>
                    <li class="list-item">
                        <a class="link" href="">
                            <i class="icon-instagram"></i>
                        </a>
                    </li>
                    <li class="list-item">
                        <a class="link" href="">
                            <i class="icon-twitter"></i>
                        </a>
                    </li>
                    <li class="list-item">
                        <a class="link" href="">
                            <i class="icon-whatsapp"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <button class="header_trigger d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#menuOffcanvas">
                <i class="icon-stream"></i>
            </button>
        </div>
    </header>
    <header class="page">
        <div class="container">
            <ul class="breadcrumbs d-flex flex-wrap align-content-center">
                <li class="list-item">
                    <a class="link" href="index.php">Home</a>
                </li>

                <li class="list-item">
                    <a class="link" href="contacts.php">Contacts</a>
                </li>
            </ul>
            <h1 class="page_title">Contacts information</h1>
        </div>
    </header>
    <main>
        <!-- contact info section start -->
        <section class="contacts_main section">
            <div class="container container--contacts d-xl-flex align-items-center">
                <div class="contacts_info col-xl-7" data-aos="fade-up">
                    <div class="contacts_info-header">
                        <h2 class="contacts_info-header_title">Contacts</h2>
                        <p class="contacts_info-header_text">
                            This is a great way to get to know the hostel that is reaching out to you for help.
                        </p>
                    </div>
                    <div class="contacts_info-main">
                        <div class="contacts_info-main_block d-sm-flex align-items-start">
                            <span class="icon-call icon">
                                <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M26.9609 19.75L21 17.1797C20.7812 17.125 20.5625 17.0703 20.3438 17.0703C19.7969 17.0703 19.3047 17.2891 19.0312 17.6719L16.625 20.625C12.7969 18.7656 9.73438 15.7031 7.875 11.875L10.8281 9.46875C11.2109 9.19531 11.4297 8.70312 11.4297 8.15625C11.4297 7.9375 11.375 7.71875 11.3203 7.5L8.75 1.53906C8.47656 0.9375 7.875 0.5 7.21875 0.5C7.05469 0.5 6.94531 0.554688 6.83594 0.554688L1.3125 1.86719C0.546875 2.03125 0 2.6875 0 3.50781C0 17.3438 11.2109 28.5 24.9922 28.5C25.8125 28.5 26.4688 27.9531 26.6875 27.1875L27.9453 21.6641C27.9453 21.5547 27.9453 21.4453 27.9453 21.2812C27.9453 20.625 27.5625 20.0234 26.9609 19.75ZM24.9375 26.75C12.1406 26.75 1.75 16.3594 1.75 3.5625L7.16406 2.30469L9.67969 8.15625L5.6875 11.4375C8.36719 17.0703 11.4297 20.1328 17.1172 22.8125L20.3438 18.8203L26.1953 21.3359L24.9375 26.75Z" fill="currentColor" />
                                </svg>
                            </span>
                            <div class="wrapper d-flex flex-column">
                                <a class="link" href="tel:">7894561232</a>
                                <a class="link" href="tel:">7894561232</a>
                            </div>
                        </div>
                        <div class="contacts_info-main_block d-sm-flex align-items-start">
                            <i class="icon-email icon"></i>
                            <div class="wrapper d-flex flex-column">
                                <a class="link" href="mailto:">test@test.com</a>
                                <a class="link" href="mailto:">test@test.com</a>
                            </div>
                        </div>
                    </div>
                    <div class="contacts_info-footer">
                        <h4 class="contacts_info-footer_header">Ask a Question ?</h4>
                        <div class="contacts_info-footer_content">
                            <p class="text">
                                How many people are in a hostel room?
                            </p>
                            <p class="text">
                                How do I keep my things safe in a hostel?

                            </p>
                        </div>
                    </div>
                </div>
                <div class="contacts_map">
                    <div id="map2"></div>
                </div>
            </div>
        </section>
        <!-- contact info section end -->
        <!-- contact form section start -->
        <section class="contacts_secondary section">
            <div class="container d-xl-flex align-items-center justify-content-between">

                <div class="contacts_secondary-form m-auto" data-aos="fade-up">
                    <div class="contacts" data-aos="fade-up">
                        <div class="contacts_header">
                            <h2 class="contacts_header-title">Get in Touch</h2>
                            <p class="contacts_header-text">
                                We would Like To Hear From You
                            </p>
                        </div>
                        <form class="contacts_form form d-sm-flex flex-wrap justify-content-between" action="mail.php" method="post">
                            <div class="field-wrapper">
                                <label class="label" for="feedbackName">
                                    <i class="icon-user icon"></i>
                                </label>
                                <input class="field required" id="feedbackName" type="text" placeholder="Name" name="name" />
                            </div>
                            <div class="field-wrapper">
                                <label class="label" for="feedbackEmail">
                                    <i class="icon-email icon"></i>
                                </label>
                                <input class="field required" id="feedbackEmail" type="text" data-type="email" placeholder="Email" name="email" />
                            </div>
                            <div class="field-wrapper" style="width: 100%;">
                                <label class="label" for="subject">
                                    <i class="icon-comment icon"></i>
                                </label>
                                <input class="field required" id="subject" type="text" placeholder="Subject" name="subject" />
                            </div>
                            <textarea class="field textarea required" id="feedbackMessage" placeholder="Message" name="message"></textarea>
                            <button class="btn theme-element theme-element--accent" type="submit" name="submit">Send message</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- contact form section end -->
    </main>
    <footer class="footer accent">
        <div class="container">
            <div class="footer_main d-sm-flex flex-wrap flex-lg-nowrap justify-content-between">
                <div class="footer_main-block footer_main-block--about col-sm-7 col-lg-auto d-flex flex-column">
                    <a class="brand d-flex align-items-center" href="index.php">
                        <span class="brand_logo theme-element">
                            <svg id="brandFooter" width="22" height="23" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.03198 3.80281V7.07652L3.86083 9.75137L0.689673 12.4263L0.667474 6.56503C0.655304 3.34138 0.663875 0.654206 0.686587 0.593579C0.71907 0.506918 1.4043 0.488223 3.87994 0.506219L7.03198 0.529106V3.80281ZM21.645 4.36419V5.88433L17.0383 9.76316C14.5046 11.8966 11.2263 14.6552 9.75318 15.8934L7.07484 18.145V20.3225V22.5H3.85988H0.64502L0.667303 18.768L0.689673 15.036L2.56785 13.4609C3.60088 12.5946 6.85989 9.85244 9.81009 7.36726L15.1741 2.84867L18.4096 2.8464L21.645 2.84413V4.36419ZM21.645 15.5549V22.5H18.431H15.217V18.2638V14.0274L15.4805 13.7882C15.8061 13.4924 21.5939 8.61606 21.6236 8.61248C21.6353 8.61099 21.645 11.7351 21.645 15.5549Z" fill="currentColor" />
                            </svg>
                        </span>
                        <span class="brand_name">Royal Hostel</span>
                    </a>
                    <p class="footer_main-block_text">
                        Our hostel is a large house where Student can stay cheaply for a short period of time.
                        Its the Hostel For the scruffy & happy backpacker.
                    </p>
                </div>
                <div class="footer_main-block footer_main-block--nav col-sm-6 col-lg-auto">
                    <h4 class="footer_main-block_header">Quick links</h4>
                    <ul class="footer_main-block_nav d-flex flex-lg-column">
                        <li class="list-item">
                            <a class="link underlined underlined--white nav-item" data-page="home" href="index.php">Home</a>
                        </li>
                        <li class="list-item">
                            <a class="link underlined underlined--white nav-item " data-page="about" href="about.php">About</a>
                        </li>
                        <li class="list-item">
                            <a class="link underlined underlined--white nav-item" data-page="rooms" href="rooms.php">Rooms</a>
                        </li>
                        <li class="list-item">
                            <a class="link underlined underlined--white nav-item current" data-page="news" href="contacts.php">Contact</a>
                        </li>
                    </ul>
                </div>
                <div class="footer_main-block footer_main-block--contacts col-sm-5 col-lg-auto">
                    <h4 class="footer_main-block_header">Contact Us</h4>
                    <ul class="footer_main-block_contacts">
                        <li class="list-item d-flex">
                            <i class="icon-location icon"></i>
                            <p class="wrapper">
                                <span class="linebreak"> BMEF Campus VIP Road,</span>
                                <span class="linebreak"> Bharthana Road, Vesu, Surat,</span>
                                <span class="linebreak"> Gujarat 395007 </span>
                            </p>
                        </li>
                        <li class="list-item d-flex">
                            <span class="icon-call icon">
                                <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M26.9609 19.75L21 17.1797C20.7812 17.125 20.5625 17.0703 20.3438 17.0703C19.7969 17.0703 19.3047 17.2891 19.0312 17.6719L16.625 20.625C12.7969 18.7656 9.73438 15.7031 7.875 11.875L10.8281 9.46875C11.2109 9.19531 11.4297 8.70312 11.4297 8.15625C11.4297 7.9375 11.375 7.71875 11.3203 7.5L8.75 1.53906C8.47656 0.9375 7.875 0.5 7.21875 0.5C7.05469 0.5 6.94531 0.554688 6.83594 0.554688L1.3125 1.86719C0.546875 2.03125 0 2.6875 0 3.50781C0 17.3438 11.2109 28.5 24.9922 28.5C25.8125 28.5 26.4688 27.9531 26.6875 27.1875L27.9453 21.6641C27.9453 21.5547 27.9453 21.4453 27.9453 21.2812C27.9453 20.625 27.5625 20.0234 26.9609 19.75ZM24.9375 26.75C12.1406 26.75 1.75 16.3594 1.75 3.5625L7.16406 2.30469L9.67969 8.15625L5.6875 11.4375C8.36719 17.0703 11.4297 20.1328 17.1172 22.8125L20.3438 18.8203L26.1953 21.3359L24.9375 26.75Z" fill="currentColor" />
                                </svg>
                            </span>
                            <p class="wrapper d-flex flex-column">
                                <a class="link" href="tel:">7894561232</a>
                                <a class="link" href="tel:">7894561232</a>
                            </p>
                        </li>
                    </ul>
                </div>
                <div class="footer_main-block footer_main-block--follow col-sm-5 col-lg-auto d-flex flex-column">
                    <h4 class="footer_main-block_header">Follow Us</h4>
                    <p class="footer_main-block_text">Facebook, Instagram Twitter, Whatsapp</p>
                    <ul class="socials d-flex align-items-center">
                        <li class="list-item">
                            <a class="link" href="#">
                                <i class="icon-facebook"></i>
                            </a>
                        </li>
                        <li class="list-item">
                            <a class="link" href="#">
                                <i class="icon-instagram"></i>
                            </a>
                        </li>
                        <li class="list-item">
                            <a class="link" href="#">
                                <i class="icon-twitter"></i>
                            </a>
                        </li>
                        <li class="list-item">
                            <a class="link" href="#">
                                <i class="icon-whatsapp"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer_copyright">
            <div class="container">
                <p class="footer_copyright-text">
                    <span class="linebreak">Royal &copy; Hostel Management</span>
                    <span class="linebreak">All rights reserved Copyrights
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                    </span>
                </p>
            </div>
        </div>
    </footer>
    <script src="js/common.min.js"></script>
    <script async src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA_C-z1hi09X8PLNpyXF-Y_hO3CGqZcScA&callback=initMap">
    </script>
    <script type="text/javascript">
        // Initialize and add the map
        function initMap() {
            // The location of Uluru
            const uluru = {
                lat: 21.1412111,
                lng: 72.7937591
            };
            // The map, centered at Uluru
            const map = new google.maps.Map(document.getElementById("map2"), {
                zoom: 16,
                center: uluru,
            });
            // The marker, positioned at Uluru
            const marker = new google.maps.Marker({
                position: uluru,
                map: map,
            });
        }
    </script>
</body>

</html>